#!/usr/bin/env python3
"""Build the APQC Process Classification Framework reference registry (D25): one read-only SKOS taxonomy of the PCF
elements, each with its hierarchy number, APQC element ID and the domain that owns it. Domain taxonomies link their
process kinds to it with skos:exactMatch or skos:broadMatch; no domain re-creates an APQC element.

    python3 _build/build_reference.py           # from the "KE Domains" folder

Reads   _build/apqc-pcf-7.2.1-category-*.txt   (element lines: "<hierarchy number> <name> (<element ID>)")
Writes  Reference/apqc-pcf/{ttl,trig}/taxonomy-apqc-pcf-<version>.{ttl,trig}

Source: APQC Cross-Industry Process Classification Framework (PCF) version 7.2.1 (September 2018). The PCF is © APQC and
free to use with attribution. Element names are kept as APQC publishes them, so the Part III label rules are not applied.
Only category 3.0 is loaded so far; add a file per category from a licensed copy (APQC has since released 8.0).
"""
import argparse, collections, datetime, pathlib, re, sys

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent
VERSION = '0.1.0'
PCF = '7.2.1'
# owner of each element (longest prefix wins): the domain concept in its area's taxonomy (D25: one owner per process)
OWNER = {
    '3.0': ('Commercial Operations', 'commercial-operations/commercial-operations-domain'),
    '3.1': ('Domain Marketing', 'commercial-operations/marketing-domain'), '3.2': ('Domain Marketing', 'commercial-operations/marketing-domain'),
    '3.2.2': ('Domain Pricing', 'commercial-operations/pricing-domain'),
    '3.2.3': ('Domain Sales.Partner & Channel', 'commercial-operations/partner-and-channel-domain'),
    '3.2.4': ('Domain Sales.Partner & Channel', 'commercial-operations/partner-and-channel-domain'),
    '3.3': ('Domain Marketing', 'commercial-operations/marketing-domain'), '3.3.3': ('Domain Pricing', 'commercial-operations/pricing-domain'),
    '3.4': ('Domain Sales', 'commercial-operations/sales-domain'),
    '3.4.2': ('Domain Sales.Partner & Channel', 'commercial-operations/partner-and-channel-domain'),
    '3.4.3.2': ('Domain Finance', 'business-operations/finance-domain'), '3.4.3.3': ('Domain Finance', 'business-operations/finance-domain'),
    '3.4.3.4': ('Domain Finance', 'business-operations/finance-domain'), '3.4.3.5': ('Domain Finance', 'business-operations/finance-domain'),
    '3.5': ('Domain Sales', 'commercial-operations/sales-domain'), '3.5.2': ('Domain Customer Care', 'commercial-operations/customer-care-domain'),
    '3.5.2.1': ('Domain Sales', 'commercial-operations/sales-domain'), '3.5.2.2': ('Domain Sales', 'commercial-operations/sales-domain'),
    '3.5.2.3': ('Domain Sales', 'commercial-operations/sales-domain'),
    '3.5.3.10': ('Domain Pricing', 'commercial-operations/pricing-domain'),
    '3.5.5': ('Domain Sales.Partner & Channel', 'commercial-operations/partner-and-channel-domain'),
}
LEVEL = {1: 'Category', 2: 'Process group', 3: 'Process', 4: 'Activity', 5: 'Task'}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split('\n')[0])
    ap.add_argument('--ingest', default=str(ROOT.parent / 'KE Workbench' / 'ingest'))
    ap.add_argument('--out', default=str(ROOT))
    a = ap.parse_args(argv)
    sys.path.insert(0, a.ingest)
    import ke_ingest as k
    cfg, _ = k.load_config(str(pathlib.Path(a.ingest) / 'ke-ingest.config.json'))
    base = cfg['baseUrl']; CORE = base + 'ontology/core/'
    ns = base + 'taxonomy/apqc-pcf/'
    t = datetime.datetime.now(datetime.timezone.utc).replace(microsecond=0)
    now = k.L(t.strftime('%Y-%m-%dT%H:%M:%SZ'), None, k.XSD + 'dateTime'); today = k.L(t.strftime('%Y-%m-%d'), None, k.XSD + 'date')
    rows = []
    for f in sorted(HERE.glob(f'apqc-pcf-{PCF}-category-*.txt')):
        for line in f.read_text(encoding='utf-8').splitlines():
            m = re.match(r'^(\d+(?:\.\d+)*) (.+) \((\d+)\)$', line.strip())
            if m: rows.append(m.groups())
    num2id = {n: i for n, _, i in rows}
    g = collections.OrderedDict()
    def add(s, p, o):
        g.setdefault(s, collections.OrderedDict()).setdefault(p, [])
        if o not in g[s][p]: g[s][p].append(o)
    def gov(s):
        add(s, k.OWL + 'versionInfo', k.L(VERSION)); add(s, CORE + 'hasLifecycleStatus', k.I(CORE + cfg['lifecycleStatus']))
        add(s, k.DCT + 'creator', k.L(cfg['author'])); add(s, k.DCT + 'created', today); add(s, k.DCT + 'modified', now)
    h = k.I(ns)
    title = 'APQC Process Classification Framework Taxonomy'
    add(h, k.RDF + 'type', k.I(k.SKOS + 'ConceptScheme'))
    for p in (k.RDFS + 'label', k.SKOS + 'prefLabel', k.DCT + 'title'): add(h, p, k.L(title, 'en'))
    add(h, k.SKOS + 'altLabel', k.L('APQC PCF Taxonomy', 'en'))
    add(h, k.DCT + 'description', k.L(f'The read-only reference registry of the APQC Cross-Industry Process Classification Framework (PCF) {PCF} (D25). Each element keeps its APQC name, hierarchy number (skos:notation) and element ID (dct:identifier), and names the one domain that owns it. Domain taxonomies link their process kinds to it; internal domain services are built on it. External services follow the HR Services & PEO Enterprise Business Model instead.', 'en'))
    add(h, k.DCT + 'source', k.L(f'APQC Cross-Industry Process Classification Framework (PCF) version {PCF}, September 2018. https://www.apqc.org/process-frameworks'))
    add(h, k.DCT + 'rights', k.L('Process Classification Framework © APQC. Used with attribution.', 'en'))
    add(h, k.DCT + 'publisher', k.I(cfg['publisher']))
    add(h, k.SKOS + 'editorialNote', k.L('Loaded so far: category 3.0 Market and Sell Products and Services. Load the other categories from a licensed copy; check numbering against PCF 8.0.', 'en'))
    add(h, k.OWL + 'versionIRI', k.I(ns + VERSION + '/'))
    add(h, k.DCT + 'identifier', k.L('taxonomy-apqc-pcf'))
    gov(h)
    def owner(n):
        best = max((x for x in OWNER if n == x or n.startswith(x + '.')), key=len)
        return OWNER[best]
    for n, name, pid in rows:
        x = k.I(ns + 'element-' + pid)
        depth = 1 if n.endswith('.0') and n.count('.') == 1 else len(n.split('.'))
        add(x, k.RDF + 'type', k.I(k.SKOS + 'Concept'))
        add(x, k.RDFS + 'label', k.L(name, 'en')); add(x, k.SKOS + 'prefLabel', k.L(name, 'en'))
        add(x, k.SKOS + 'notation', k.L(n)); add(x, k.DCT + 'identifier', k.L(pid))
        add(x, k.SKOS + 'scopeNote', k.L(f'APQC PCF {PCF} {LEVEL[depth].lower()}.', 'en'))
        add(x, k.SKOS + 'inScheme', h)
        if depth == 1:
            add(x, k.SKOS + 'topConceptOf', h); add(h, k.SKOS + 'hasTopConcept', x)
        else:
            parent = '3.0' if depth == 2 else n.rsplit('.', 1)[0]
            px = k.I(ns + 'element-' + num2id[parent])
            add(x, k.SKOS + 'broader', px); add(px, k.SKOS + 'narrower', x)
        label, concept = owner(n)
        add(x, k.SKOS + 'related', k.I(base + 'taxonomy/' + concept))
        add(x, k.SKOS + 'editorialNote', k.L(f'Owner: {label}.', 'en'))
        gov(x)
    pfx = {'core': CORE, 'rdf': k.RDF, 'rdfs': k.RDFS, 'owl': k.OWL, 'skos': k.SKOS, 'dct': k.DCT, 'xsd': k.XSD, 'apqc': ns,
           'commercialopstax': base + 'taxonomy/commercial-operations/', 'businessopstax': base + 'taxonomy/business-operations/'}
    w = k.Writer(pfx, [CORE + 'hasLifecycleStatus'] + k.GOV_TAIL[1:])
    subjects = [h] + [s for s in g if s != h]
    head = (f'# {title}\n# {ns}  ·  version {VERSION}  ·  {cfg["lifecycleStatus"]}  ·  source APQC PCF {PCF} (read-only reference, D25)\n'
            f'# Generated by build_reference.py on {now[1]}\n# Standards: {cfg["standardsRef"]}\n')
    text = w.write(g, subjects, head)
    trig = w.write_trig(g, subjects, head.replace('\n# Standards', f'\n# Named graph: {ns}\n# Standards'), ns)
    k.parse_turtle(text)
    out = pathlib.Path(a.out) / 'Reference' / 'apqc-pcf'
    for sub, body in (('ttl', text), ('trig', trig)):
        (out / sub).mkdir(parents=True, exist_ok=True)
        (out / sub / f'taxonomy-apqc-pcf-{VERSION}.{sub}').write_text(body, encoding='utf-8')
    print(f'{len(rows)} APQC PCF {PCF} elements → {out}')


if __name__ == '__main__':
    sys.exit(main())
