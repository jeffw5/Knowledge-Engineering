# KE Workbench

One workbench for knowledge engineering. It brings the modeling tools, the SSOT for rules and logic, and the agent operations dashboards together under one overview, with a light/dark toggle. It applies the Part III standards of *Semantic Governance: Services, Architecture & Integration* v1.8 (Draft).

## Run it

**Easiest (Mac):** double-click `start-workbench.command` in Finder. It stops any older workbench server on port 3000, starts this folder's `proxy.py` and opens http://localhost:3000/. (The first time, macOS may ask you to confirm: right-click → Open.)

**From a terminal:**

```bash
cd ~/Documents/GitHub/Knowledge-Engineering/"KE Workbench"
python3 proxy.py            # GraphDB on http://localhost:7200
# open http://localhost:3000/
```

Always open the workbench through `http://localhost:3000/`, never by double-clicking `index.html` (a `file://` page can't reach GraphDB). `proxy.py` serves the folder it sits in and prints that folder when it starts; it tells the browser not to cache the pages, so an updated tool shows up on the next reload. If it reports that port 3000 is in use, an older proxy is still running: `lsof -ti tcp:3000 | xargs kill`. It listens on this computer only; start it with `HOST=0.0.0.0` to share it on your network. To point it at another GraphDB, set `GRAPHDB_URL=http://host:7200` and/or `PORT=3000`.

The Overview shows the workbench release (currently **1.3.0**); click it, or open *Reference › Release Notes*, for the change log. To record a release, add an entry at the top of `assets/ke-releases.js` and bump `version` in `assets/ke-registry.js`.

Without GraphDB, the static tools still work: SSOT, dashboards, personas, HSGA, and Standards Conformance in Turtle-file mode. The pill in the top bar shows the connection.

## Layout

| Path | What |
|---|---|
| `start-workbench.command` | Double-click launcher (Mac) |
| `tools/release-notes.html`, `assets/ke-releases.js` | Release Notes page and the release history it shows |
| `index.html` | Workbench shell: grouped navigation, tabs that keep their state, GraphDB status, settings, light/dark |
| `tools/workbench-overview.html` | Overview: live asset counts, tool map, §1.3 function mapping, Part III quick reference, E.3 checklist |
| `tools/standards-conformance.html` | **New.** Checks GraphDB graphs or a Turtle file against the Part III / Appendix E standards |
| `tools/*.html` | Your existing tools, renamed (see below) |
| `assets/ke-theme.css` | Design tokens taken from the guide (Liberation Sans, ink `#1F2933`, accent `#2F6DB5`, band `#EEF3F9`, rule `#D5DBE1`, draft red `#B03A2E`), plus a dark theme |
| `assets/ke-bridge.js` | Loaded by every tool: theme sync, `window.open`/`window.close`/`_blank` links become workbench tabs, shared repository ID |
| `assets/ke-registry.js` | The tool list used by the shell and the overview — add new tools here |
| `tools/model-editor-taxonomy.html`, `tools/model-editor-ontology.html` | **New.** The two simplified Model Editors (see below) |
| `assets/ke-sparql.js` | SPARQL helpers shared by the Model Editors (all calls go through the proxy) |
| `assets/ke-turtle.js`, `ke-rules.js`, `ke-sample.js` | Turtle parser, conformance rules, sample file |
| `docs/` | The standards guide (PDF) |
| `legacy/` | Superseded versions kept for reference (`operational_dashboard.html`, `model-metadata.html`) |

## What changed in your tools

- **All tools:** the bridge script and a small theme adapter were added. The adapters map each page's colors onto the shared tokens, so every tool follows the workbench light/dark toggle. Each page still works on its own, outside the workbench.
- **Model Manager:** restyled to match the workbench; each asset is listed once (it used to repeat when an asset had several labels or matched in more than one graph), with counts per tab and a filter. The compliant base URLs are now a setting (gear: GraphDB pill → *Compliant base URLs*). The default is `https://www.insperity.com/` (§3.2) plus the legacy `https://www.enablingvalue.com/`. The Create-new template follows the URI pattern. Slash-terminated IRIs now show their last segment.
- **OWL / SKOS / Taxonomy metadata editors:** `owl:versionInfo` uses semantic versioning (§3.3). A metadata save bumps PATCH, a new asset starts at `0.1.0`, and legacy `1.3` becomes `1.3.1`.
- **Visualizer:** labels follow the theme; `insperity.com` has its own color.
- **SSOT Rules Map / Agent & Service Map:** links to the hosted SSOT Editor open the local copy as a tab. URLs written into downloadable packages are unchanged.
- **Tailwind CDN** is pinned to 3.4.17.

## Model Editors

The classic `model-editor.html` is replaced in the navigation by two focused editors. It is still in `tools/` (hidden from the nav).

**Model Editor (Taxonomy)** — choose a taxonomy (any asset whose IRI contains "taxonomy"; tick *all* to see every scheme and ontology). It works with both kinds of taxonomy in the repository:
- **OWL taxonomies** (`owl:Ontology` with `owl:Class` terms, as in `taxonomy-core-*`): members are classes with `rdfs:isDefinedBy` the taxonomy, in its named graph, or in its namespace (`IRI/…` or `IRI#…`) unless defined by another model; broader/narrower is `rdfs:subClassOf`. A vocabulary term dropped in reuses the class already linked to it by `dc:subject` (or a class with the same label); otherwise a new class is created in the taxonomy's namespace, named from the label in PascalCase, with `rdfs:label`, `rdfs:isDefinedBy` and `dc:subject` pointing back to the vocabulary term.
- **SKOS taxonomies** (`skos:ConceptScheme`): `skos:inScheme`, `skos:broader`/`skos:narrower`, `skos:topConceptOf`/`skos:hasTopConcept`.

Pick a vocabulary on the left and select terms (Ctrl/⌘-click, Shift-click, *All*). Dragging uses the mouse directly (press, move, release); a label follows the pointer and the drop target is highlighted.
- Drop **on** a term: the dragged terms become its narrower terms (moving them from their old place).
- Drop on the **top edge** of a term: the dragged term becomes its broader term and takes its place.
- Drop on the dashed zone: top level. Hold **Alt/⌥** to add a second broader term instead of moving. Delete removes a term from the taxonomy (its children move up; for an OWL taxonomy the class's statements are deleted after a confirmation).
- Changes are pending until **Save**. They are written to the taxonomy's named graph, or to the default graph when it has none. Undo with Ctrl/⌘-Z; moves that would create a cycle are refused.

**Model Editor (Ontology)** — choose the ontology to edit: its class hierarchy is drawn on the canvas as a left-to-right tree (each class under its most specific parent; *is a* lines implied by another *is a* are not drawn, but the triples are untouched and the Inspector lists them all). It and its `owl:imports` load on the left automatically, and you can tick any other ontology, taxonomy or vocabulary.
- Drag single terms from the Terms list, or drag a **whole model** from the Models list, onto the canvas — a model is placed as its own hierarchy where you drop it. *Show ontology* redraws the edited ontology (Undo restores the previous canvas).
- Drag from a node's **+** handle to another node and pick a relation.
- The relation list is every `owl:ObjectProperty` with an `obo:BFO_` or `obo:RO_` IRI in the repository (BFO plus the RO core relations; deprecated ones are hidden), or the properties of another ontology chosen in ⚙. It is ordered by `rdfs:subPropertyOf`, with definitions from `IAO:0000115`. *is a* (`rdfs:subClassOf`) is always available. If BFO isn't in the repository, *Load BFO 2020* asks GraphDB to load it.
- Classes are related with `rdfs:subClassOf [ owl:onProperty R ; owl:someValuesFrom B ]` by default; *only (∀)* and *direct triple* (for concepts) are also offered.
- Relations whose subject belongs to the ontology (`rdfs:isDefinedBy` or its named graph) are drawn when both ends are on the canvas (*Show relations* places them). On Save, terms from other models get an `owl:imports` for their model (switch off in ⚙). The canvas layout is remembered per ontology in the browser.

## Not included

Model Manager links to `voc-editor.html`, which wasn't among the source files (its Taxonomy button now opens the Taxonomy Model Editor). The workbench shows a placeholder tab for them. Drop the files into `tools/` and they'll open normally.

## Standards Conformance rules

Base URL · URI pattern · identifier case · no acronyms in identifiers · no acronyms in preferred labels · label present with `@en` · sentence-case labels · definition present · genus + differentia · named parent class · `rdfs:isDefinedBy` · property domain and range · restricted OWL constructs · concept in scheme with one prefLabel · no version in term IRIs · semantic version on releases · one scheme per taxonomy with top concepts flagged.
