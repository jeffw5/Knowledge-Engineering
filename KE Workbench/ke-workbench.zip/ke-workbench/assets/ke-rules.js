/* KE Workbench — Standards Conformance rules.
   Each rule encodes a Part III / Appendix E standard from Semantic Governance v1.8.
   runChecks(quads, { bases }) → { rules:[{...rule, checked, failed}], findings:[...], stats }
   quads: [{ s, p, o, g }] with terms { t:'iri'|'bnode'|'lit', v, lang?, dt? } */
(function (root) {
  var RDF = 'http://www.w3.org/1999/02/22-rdf-syntax-ns#', RDFS = 'http://www.w3.org/2000/01/rdf-schema#',
      OWL = 'http://www.w3.org/2002/07/owl#', SKOS = 'http://www.w3.org/2004/02/skos/core#',
      SH = 'http://www.w3.org/ns/shacl#';
  var P = {
    type: RDF + 'type', label: RDFS + 'label', pref: SKOS + 'prefLabel', alt: SKOS + 'altLabel',
    def: SKOS + 'definition', sub: RDFS + 'subClassOf', isDef: RDFS + 'isDefinedBy', dom: RDFS + 'domain',
    rng: RDFS + 'range', inScheme: SKOS + 'inScheme', topOf: SKOS + 'topConceptOf', hasTop: SKOS + 'hasTopConcept',
    ver: OWL + 'versionInfo', verIri: OWL + 'versionIRI', eq: OWL + 'equivalentClass', dju: OWL + 'disjointUnionOf'
  };
  // Predicates the GraphDB loader needs to fetch
  var PREDICATES = Object.keys(P).map(function (k) { return P[k]; });

  var EXTERNAL = [/^https?:\/\/www\.w3\.org\//, /^https?:\/\/purl\.org\//, /^https?:\/\/xmlns\.com\//, /^https?:\/\/purl\.obolibrary\.org\//,
    /^https?:\/\/schema\.org\//, /^https?:\/\/www\.linkedmodel\.org\//, /^https?:\/\/qudt\.org\//, /^https?:\/\/www\.omg\.org\//,
    /^https?:\/\/spec\.edmcouncil\.org\//, /^https?:\/\/www\.ontologydesignpatterns\.org\//, /^urn:/];
  var AREAS = ['ontology', 'vocabulary', 'taxonomy', 'mapping', 'shapes', 'resource', 'graph', 'change', 'requirement'];

  function kindOf(e) {
    var t = e.types;
    if (t.has(OWL + 'Ontology')) return 'ontology';
    if (t.has(SKOS + 'ConceptScheme')) return 'scheme';
    if (t.has(SKOS + 'Concept')) return 'concept';
    if (t.has(OWL + 'ObjectProperty')) return 'objprop';
    if (t.has(OWL + 'DatatypeProperty')) return 'dataprop';
    if (t.has(OWL + 'AnnotationProperty')) return 'annprop';
    if (t.has(OWL + 'Class') || t.has(RDFS + 'Class')) return 'class';
    if (t.has(SH + 'NodeShape')) return 'shape';
    if (t.has(OWL + 'NamedIndividual')) return 'individual';
    return null;
  }
  var KIND_LABEL = { ontology: 'Ontology', scheme: 'Concept scheme', concept: 'Concept', objprop: 'Object property',
    dataprop: 'Data property', annprop: 'Annotation property', class: 'Class', shape: 'Shape', individual: 'Individual' };
  var TERM = { class: 1, objprop: 1, dataprop: 1, concept: 1 };
  var PROP = { objprop: 1, dataprop: 1 };

  function localName(iri) {
    var s = iri.replace(/[\/#]+$/, '');
    var i = Math.max(s.lastIndexOf('/'), s.lastIndexOf('#'));
    return decodeURIComponentSafe(s.slice(i + 1));
  }
  function decodeURIComponentSafe(s) { try { return decodeURIComponent(s); } catch (e) { return s; } }
  function vals(e, p) { return e.p[p] || []; }
  function lits(e, p) { return vals(e, p).filter(function (o) { return o.t === 'lit'; }); }
  function prefLabels(e) { return lits(e, P.pref).length ? lits(e, P.pref) : lits(e, P.label); }
  function anyLabel(e) { var l = prefLabels(e); var en = l.filter(function (x) { return x.lang === 'en'; }); return (en[0] || l[0] || {}).v || ''; }
  function concepKind(e) { return /\/taxonomy\//.test(e.iri) ? 'taxonomy' : /\/vocabulary\//.test(e.iri) ? 'vocabulary' : null; }

  var ACRONYM = /\b(?![IVX]+\b)[A-Z]{2,}s?\b/;          // PEO, FMLA, HRs — not roman numerals
  var CAMEL_ACRONYM = /[A-Z]{2,}(?=[A-Z][a-z]|$|[0-9_-])|[A-Z]{3,}/;

  function rules(ctx) {
    var bases = ctx.bases, primary = bases[0];
    function underBase(iri) { var u = iri.toLowerCase(); return bases.some(function (b) { return u.indexOf(b.toLowerCase()) === 0; }); }
    function baseOf(iri) { var u = iri.toLowerCase(); return bases.filter(function (b) { return u.indexOf(b.toLowerCase()) === 0; })[0]; }
    function segs(iri) { var b = baseOf(iri); return b ? iri.slice(b.length).split(/[?#]/)[0].split('/').filter(Boolean) : []; }

    return [
      { id: 'base-url', sec: '3.2', sev: 'error', title: 'Company base URL',
        desc: 'Every identifier lives under the base URL (' + primary + ').',
        applies: function (e) { return !!e.kind; },
        check: function (e) { return underBase(e.iri) ? null : 'Outside the compliant base URLs: ' + e.iri.replace(/^(https?:\/\/[^\/]+\/?).*/, '$1'); } },

      { id: 'uri-pattern', sec: '3.2', sev: 'warn', title: 'URI pattern',
        desc: 'Slash-based namespaces: /{ontology|vocabulary|taxonomy|mapping|shapes|resource}/{domain}/{Term}, domain in lower-case hyphenated words.',
        applies: function (e) { return !!e.kind && underBase(e.iri); },
        check: function (e) {
          if (e.iri.indexOf('#') >= 0) return 'Hash namespace — use slash-based IRIs so each term resolves on its own';
          var s = segs(e.iri);
          if (!s.length) return 'No path after the base URL';
          if (AREAS.indexOf(s[0]) < 0) return 'First path segment "' + s[0] + '" is not one of ' + AREAS.slice(0, 6).join(', ');
          var want = e.kind === 'concept' || e.kind === 'scheme' ? ['vocabulary', 'taxonomy'] : e.kind === 'shape' ? ['shapes'] : (TERM[e.kind] || PROP[e.kind] || e.kind === 'ontology' || e.kind === 'annprop') ? ['ontology'] : null;
          if (want && want.indexOf(s[0]) < 0) return KIND_LABEL[e.kind] + ' is under /' + s[0] + '/ — expected /' + want.join('/ or /') + '/';
          if (s.length > 1 && !/^[a-z0-9]+(-[a-z0-9]+)*$/.test(s[1]) && !/^\d+\.\d+/.test(s[1])) return 'Domain segment "' + s[1] + '" should be lower-case words joined by hyphens';
          if ((TERM[e.kind] || e.kind === 'shape') && s.length > 3 && !/^\d+\.\d+/.test(s[2])) return 'Hierarchy in the path — keep {domain}/{Term} and move the hierarchy into rdfs:subClassOf or skos:broader';
          return null;
        } },

      { id: 'name-case', sec: '3.2', sev: 'warn', title: 'Identifier case',
        desc: 'Classes and taxonomy concepts UpperCamelCase; object properties lowerCamelCase; data properties has-/is- prefix; vocabulary terms lower-case hyphenated; shapes end in Shape.',
        applies: function (e) { return (TERM[e.kind] || e.kind === 'shape') && !!localName(e.iri); },
        check: function (e) {
          var n = localName(e.iri);
          if (/[_:\s]/.test(n)) return '"' + n + '" contains underscores, colons or spaces';
          if (e.kind === 'class' && !/^[A-Z][A-Za-z0-9]*$/.test(n)) return 'Class "' + n + '" should be UpperCamelCase';
          if (e.kind === 'objprop' && !/^[a-z][A-Za-z0-9]*$/.test(n)) return 'Object property "' + n + '" should be a lowerCamelCase verb phrase';
          if (e.kind === 'dataprop' && !/^(has|is)[A-Z][A-Za-z0-9]*$/.test(n)) return 'Data property "' + n + '" should be lowerCamelCase with a has- or is- prefix';
          if (e.kind === 'shape' && !/^[A-Z][A-Za-z0-9]*Shape$/.test(n)) return 'Shape "' + n + '" should be the target class name plus Shape';
          if (e.kind === 'concept') {
            var ck = concepKind(e);
            if (ck === 'taxonomy' && !/^[A-Z][A-Za-z0-9]*$/.test(n)) return 'Taxonomy concept "' + n + '" should be UpperCamelCase';
            if (ck === 'vocabulary' && !/^[a-z0-9]+(-[a-z0-9]+)*$/.test(n)) return 'Vocabulary term "' + n + '" should be lower-case words joined by hyphens';
          }
          return null;
        } },

      { id: 'acronym-id', sec: '3.2', sev: 'error', title: 'No acronyms in identifiers',
        desc: 'Identifiers use full words: ProfessionalEmployerOrganization, not PEO.',
        applies: function (e) { return (TERM[e.kind] || e.kind === 'shape' || e.kind === 'individual') && !!localName(e.iri); },
        check: function (e) { var n = localName(e.iri), m = n.match(CAMEL_ACRONYM) || n.match(/(^|[_-])([A-Z]{2,})(?=[_-]|$)/);
          return m ? 'Identifier "' + n + '" contains the acronym "' + (m[2] || m[0]).replace(/[^A-Z]/g, '') + '"' : null; } },

      { id: 'acronym-label', sec: '3.2', sev: 'error', title: 'No acronyms in preferred labels',
        desc: 'Acronyms belong in skos:altLabel only, so search still finds them.',
        applies: function (e) { return !!e.kind && prefLabels(e).length > 0; },
        check: function (e) { var bad = prefLabels(e).filter(function (l) { return ACRONYM.test(l.v); });
          return bad.length ? 'Preferred label "' + bad[0].v + '" contains "' + bad[0].v.match(ACRONYM)[0] + '" — spell it out and move the acronym to skos:altLabel' : null; } },

      { id: 'label', sec: '3.7', sev: 'error', title: 'Label present, tagged @en',
        desc: 'rdfs:label and skos:prefLabel, one per language, tagged with a language.',
        applies: function (e) { return !!TERM[e.kind] || e.kind === 'scheme' || e.kind === 'ontology'; },
        check: function (e) {
          var all = lits(e, P.label).concat(lits(e, P.pref));
          if (!all.length) return 'No rdfs:label or skos:prefLabel';
          var untagged = all.filter(function (l) { return !l.lang; });
          if (untagged.length) return 'Label "' + untagged[0].v + '" has no language tag (add @en)';
          return null;
        } },

      { id: 'sentence-case', sec: '3.2', sev: 'warn', title: 'Sentence-case labels',
        desc: 'Preferred labels are written in sentence case: "Pay period", not "Pay Period".',
        applies: function (e) { return !!TERM[e.kind] && prefLabels(e).length > 0; },
        check: function (e) {
          var bad = prefLabels(e).filter(function (l) {
            var w = l.v.trim().split(/\s+/); if (w.length < 2) return false;
            var caps = w.slice(1).filter(function (x) { return /^[A-Z][a-z]/.test(x) && x.length > 2; });
            return caps.length >= Math.max(1, Math.ceil((w.length - 1) / 2));
          });
          return bad.length ? 'Label "' + bad[0].v + '" looks like Title Case' : null;
        } },

      { id: 'definition', sec: '3.7', sev: 'error', title: 'Definition present',
        desc: 'Every class, concept and property carries one skos:definition.',
        applies: function (e) { return !!TERM[e.kind]; },
        check: function (e) { var d = lits(e, P.def);
          if (!d.length) return 'No skos:definition';
          if (d.filter(function (x) { return x.lang === 'en'; }).length > 1) return 'More than one English definition';
          return null; } },

      { id: 'genus', sec: '3.7', sev: 'info', title: 'Genus plus differentia',
        desc: 'One sentence, ISO 704 form: "A [parent] that [distinguishing feature]".',
        applies: function (e) { return !!TERM[e.kind] && lits(e, P.def).length > 0; },
        check: function (e) {
          var d = lits(e, P.def)[0].v.replace(/\s+/g, ' ').trim();
          if (!/^(A|An)\s/.test(d)) return 'Definition does not open with "A …" / "An …" (genus first)';
          if ((d.replace(/\b(e\.g|i\.e|etc)\./g, '').match(/[.!?](\s|$)/g) || []).length > 1) return 'Definition runs to more than one sentence';
          if (d.split(' ').length < 6) return 'Definition is very short — add the distinguishing feature';
          return null;
        } },

      { id: 'parent', sec: '3.7', sev: 'error', title: 'Named parent class',
        desc: 'At least one named rdfs:subClassOf parent (not owl:Thing); the hierarchy carries the meaning.',
        applies: function (e) { return e.kind === 'class'; },
        check: function (e) { var named = vals(e, P.sub).filter(function (o) { return o.t === 'iri' && o.v !== OWL + 'Thing'; });
          return named.length ? null : 'No named rdfs:subClassOf parent'; } },

      { id: 'defined-by', sec: '3.7', sev: 'warn', title: 'rdfs:isDefinedBy',
        desc: 'The IRI of the ontology that owns the term.',
        applies: function (e) { return e.kind === 'class' || !!PROP[e.kind]; },
        check: function (e) { return vals(e, P.isDef).length ? null : 'No rdfs:isDefinedBy'; } },

      { id: 'domain-range', sec: '3.10', sev: 'warn', title: 'Property domain and range',
        desc: 'Every property has a domain and range (and edges draw in the editor).',
        applies: function (e) { return !!PROP[e.kind]; },
        check: function (e) { var miss = [];
          if (!vals(e, P.dom).length) miss.push('rdfs:domain'); if (!vals(e, P.rng).length) miss.push('rdfs:range');
          return miss.length ? 'Missing ' + miss.join(' and ') : null; } },

      { id: 'avoid-axioms', sec: '3.7', sev: 'info', title: 'Restricted OWL constructs',
        desc: 'owl:equivalentClass only with Architecture approval; avoid owl:disjointUnionOf.',
        applies: function (e) { return e.kind === 'class'; },
        check: function (e) {
          if (vals(e, P.dju).length) return 'Uses owl:disjointUnionOf — use subclasses plus owl:AllDisjointClasses';
          if (vals(e, P.eq).length) return 'Uses owl:equivalentClass — needs Architecture approval (forces run-time inference)';
          return null; } },

      { id: 'in-scheme', sec: '3.9', sev: 'error', title: 'Concept in scheme, one preferred label',
        desc: 'Every concept has skos:inScheme and exactly one skos:prefLabel per language.',
        applies: function (e) { return e.kind === 'concept'; },
        check: function (e) {
          var problems = [];
          if (!vals(e, P.inScheme).length && !vals(e, P.topOf).length) problems.push('no skos:inScheme');
          var byLang = {}; lits(e, P.pref).forEach(function (l) { var k = l.lang || '(none)'; byLang[k] = (byLang[k] || 0) + 1; });
          if (!lits(e, P.pref).length) problems.push('no skos:prefLabel');
          Object.keys(byLang).forEach(function (k) { if (byLang[k] > 1) problems.push(byLang[k] + ' preferred labels for ' + k); });
          return problems.length ? problems.join('; ') : null; } },

      { id: 'versioned-term', sec: '3.3', sev: 'error', title: 'No version in term IRIs',
        desc: 'Only ontology and vocabulary releases get versioned IRIs; class, property and concept IRIs never do.',
        applies: function (e) { return !!TERM[e.kind]; },
        check: function (e) { var m = e.iri.match(/\/v?\d+\.\d+(\.\d+)?\//); return m ? 'Term IRI contains a version segment "' + m[0] + '"' : null; } },

      { id: 'version-format', sec: '3.3', sev: 'warn', title: 'Semantic version on releases',
        desc: 'Ontologies and schemes carry owl:versionInfo as MAJOR.MINOR.PATCH; ontology releases add owl:versionIRI.',
        applies: function (e) { return e.kind === 'ontology' || e.kind === 'scheme'; },
        check: function (e) { var v = lits(e, P.ver);
          if (!v.length) return 'No owl:versionInfo';
          if (!/^\d+\.\d+\.\d+$/.test(v[0].v.trim())) return 'owl:versionInfo "' + v[0].v + '" is not MAJOR.MINOR.PATCH';
          if (e.kind === 'ontology' && !vals(e, P.verIri).length) return 'No owl:versionIRI for this release';
          return null; } }
    ];
  }

  // Graph-level rule: one concept scheme per taxonomy graph / file
  function graphRule(entities) {
    var byGraph = {};
    entities.forEach(function (e) { if (e.kind === 'scheme' && /\/taxonomy\//.test(e.iri)) e.graphs.forEach(function (g) { (byGraph[g] = byGraph[g] || []).push(e); }); });
    var findings = [], checked = 0;
    Object.keys(byGraph).forEach(function (g) {
      checked++;
      var schemes = byGraph[g];
      if (schemes.length > 1) findings.push({ iri: g, kind: 'graph', detail: schemes.length + ' taxonomy concept schemes in one graph — declare exactly one' });
      schemes.forEach(function (s) {
        var hasTop = (s.p[P.hasTop] || []).length || entities.some(function (c) { return (c.p[P.topOf] || []).some(function (o) { return o.v === s.iri; }); });
        if (!hasTop) findings.push({ iri: s.iri, kind: 'scheme', detail: 'No top concepts flagged (skos:hasTopConcept / skos:topConceptOf)' });
      });
    });
    return { rule: { id: 'one-scheme', sec: 'E.3', sev: 'error', title: 'One scheme per taxonomy, top concepts flagged',
      desc: 'Declare exactly one skos:ConceptScheme per taxonomy and flag its top concepts.' }, findings: findings, checked: checked };
  }

  function buildEntities(quads) {
    var map = new Map();
    quads.forEach(function (q) {
      if (!q.s || q.s.t !== 'iri') return;
      var e = map.get(q.s.v);
      if (!e) { e = { iri: q.s.v, types: new Set(), p: {}, graphs: new Set() }; map.set(q.s.v, e); }
      e.graphs.add(q.g || 'default');
      if (q.p.v === P.type && q.o.t === 'iri') e.types.add(q.o.v);
      (e.p[q.p.v] = e.p[q.p.v] || []).push(q.o);
    });
    var out = [];
    map.forEach(function (e) {
      e.kind = kindOf(e);
      if (!e.kind) return;
      if (EXTERNAL.some(function (rx) { return rx.test(e.iri); })) return;   // references to external vocabularies
      out.push(e);
    });
    return out;
  }

  function runChecks(quads, opts) {
    var bases = (opts && opts.bases && opts.bases.length) ? opts.bases : ['https://www.insperity.com/'];
    var entities = buildEntities(quads), R = rules({ bases: bases }), findings = [], summary = [];
    R.forEach(function (r) {
      var checked = 0, failed = 0;
      entities.forEach(function (e) {
        if (!r.applies(e)) return;
        checked++;
        var msg = r.check(e);
        if (msg) { failed++; findings.push({ rule: r.id, sev: r.sev, sec: r.sec, iri: e.iri, kind: e.kind, label: anyLabel(e), detail: msg }); }
      });
      summary.push({ id: r.id, sec: r.sec, sev: r.sev, title: r.title, desc: r.desc, checked: checked, failed: failed });
    });
    var g = graphRule(entities);
    g.findings.forEach(function (f) { findings.push({ rule: g.rule.id, sev: g.rule.sev, sec: g.rule.sec, iri: f.iri, kind: f.kind, label: '', detail: f.detail }); });
    summary.push(Object.assign({}, g.rule, { checked: g.checked, failed: g.findings.length }));
    var kinds = {}; entities.forEach(function (e) { kinds[e.kind] = (kinds[e.kind] || 0) + 1; });
    return { rules: summary, findings: findings, stats: { entities: entities.length, kinds: kinds, triples: quads.length } };
  }

  root.KE_RULES = { runChecks: runChecks, PREDICATES: PREDICATES, KIND_LABEL: KIND_LABEL, localName: localName };
  if (typeof module !== 'undefined') module.exports = root.KE_RULES;
})(typeof window !== 'undefined' ? window : globalThis);
