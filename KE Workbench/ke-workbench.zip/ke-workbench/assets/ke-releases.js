/* KE Workbench — release history (newest first). Shown on the Release Notes page.
   Add a new entry at the top for every release and bump `version` in ke-registry.js to match. */
window.KE_RELEASES = [
  {
    version: '1.3.0', date: '2026-10-15', title: 'Ontology canvas and release notes',
    groups: [
      { kind: 'new', items: [
        'Release Notes page (Reference › Release Notes); the release number on the Overview links to it.',
        'Model Editor (Ontology): choosing an ontology draws its whole class hierarchy on the canvas as a left-to-right tree, each class under its most specific parent.',
        'Model Editor (Ontology): drag a whole model — ontology, taxonomy or vocabulary — from the Models list onto the canvas; its terms are placed as their own hierarchy where you drop it.',
        'Model Editor (Ontology): “Show ontology” button redraws the edited ontology’s hierarchy (Undo restores the previous canvas).'
      ]},
      { kind: 'improved', items: [
        '“is a” lines implied by another “is a” (A is a B, B is a C ⇒ A is a C) are no longer drawn, so broad ontologies stay readable; the triples are untouched and the Inspector still lists every relation.',
        'Large hierarchies open centred on the root at a readable zoom instead of shrinking to fit.',
        'Both Model Editors find the terms of models that only use a namespace (IRI#… or IRI/…) — e.g. Ontology | Domain | Governance — unless a term is defined by another model.'
      ]},
      { kind: 'fixed', items: [
        'An empty saved canvas no longer hides an ontology when it is opened again.'
      ]}
    ]
  },
  {
    version: '1.2.0', date: '2026-10-15', title: 'Model editors on real data',
    groups: [
      { kind: 'new', items: [
        'start-workbench.command: double-click launcher for the Mac that stops an older server on port 3000, starts this folder’s proxy and opens the workbench.',
        'Model Editor (Taxonomy) supports OWL taxonomies (owl:Class + rdfs:subClassOf, as in taxonomy-core-*) as well as SKOS concept schemes.',
        'Dropping a vocabulary term on an OWL taxonomy reuses the class already linked by dc:subject (or a class with the same label), otherwise creates a class named from the label with rdfs:label, rdfs:isDefinedBy and dc:subject.'
      ]},
      { kind: 'improved', items: [
        'Model Manager restyled to match the workbench, with counts per Voc / Tax / Ont / Other tab and a filter.',
        'Model Editor (Ontology) lists BFO and RO core relations (obo:BFO_ and obo:RO_), hides deprecated ones, and finds relations of ontologies stored in the default graph.',
        'Edits go to the model’s named graph, or to the default graph when it has none.',
        'proxy.py tells the browser not to cache pages, so an updated tool appears on the next reload; it listens on IPv4 and IPv6 localhost, handles requests in parallel, prints the folder it serves and explains when port 3000 is already in use.'
      ]},
      { kind: 'fixed', items: [
        'Drag and drop in both Model Editors now uses the pointer directly — browser drag-and-drop did not work inside workbench tabs and embedded browser panes.',
        'Model Manager listed some assets twice (several labels, or a match both inside and outside a named graph).',
        'Model Editor (Taxonomy) showed “No taxonomies found” because the taxonomies are OWL ontologies, not SKOS schemes.'
      ]}
    ]
  },
  {
    version: '1.1.0', date: '2026-10-14', title: 'Model Editors',
    groups: [
      { kind: 'new', items: [
        'Model Editor (Taxonomy): pick a taxonomy, drag vocabulary terms onto it — drop on a term to make them narrower, on its top edge to make one broader; Alt/⌥ adds a second broader term.',
        'Model Editor (Ontology): load ontologies and taxonomies on the left, drag terms onto a canvas and relate them with a relation chosen from BFO.',
        'assets/ke-sparql.js: shared SPARQL helpers; every query goes through the proxy.'
      ]},
      { kind: 'improved', items: [
        'The classic Model Editor is hidden from the navigation (still in tools/).',
        'Model Manager’s Taxonomy and Edit buttons open the new editors through the proxy instead of calling GraphDB on port 7200 directly.'
      ]}
    ]
  },
  {
    version: '1.0.0', date: '2026-10-14', title: 'KE Workbench',
    groups: [
      { kind: 'new', items: [
        'One workbench shell for the modeling tools, the SSOT for rules and logic, and the agent operations dashboards, with tabs that keep their state, a GraphDB status pill and a light/dark theme.',
        'Overview page with live asset counts, tool map, §1.3 function mapping, Part III quick reference and the E.3 checklist.',
        'Standards Conformance: checks GraphDB graphs or a Turtle file against the Part III / Appendix E standards.',
        'proxy.py serves the workbench and forwards /graphdb/* to GraphDB, so there are no CORS problems.'
      ]},
      { kind: 'improved', items: [
        'All tools follow the workbench theme and open their links as workbench tabs.',
        'Model Manager: compliant base URLs are a setting (default https://www.insperity.com/ plus the legacy https://www.enablingvalue.com/).',
        'OWL / SKOS / Taxonomy metadata editors use semantic versioning for owl:versionInfo.'
      ]}
    ]
  }
];
