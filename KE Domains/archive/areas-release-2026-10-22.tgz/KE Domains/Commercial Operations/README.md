# Commercial Operations

The operational area that sells, markets, prices and cares for the organization's offerings and clients (D26). Built on Baseline Core v1.0; see `../README.md` for the hierarchy, naming and insulation rules.

| Folder | Asset names | IRIs |
|---|---|---|
| `commercial-operations/` | Commercial Operations Vocabulary, Taxonomy, Ontology, Shapes (0.4.0): what two or more of the area's domains share, and a taxonomy of its domains | `…/<kind>/commercial-operations/` |
| `sales/` | Domain Sales (0.4.0) | `…/<kind>/domain-sales/` |
| `sales/partner-and-channel/` | Domain Sales.Partner & Channel (0.2.0), an L2 domain of Sales | `…/<kind>/domain-sales.partner-and-channel/` |
| `marketing/` | Domain Marketing (0.2.0), including competitive intelligence | `…/<kind>/domain-marketing/` |
| `pricing/` | Domain Pricing (0.3.0), formerly Pricing and contracts | `…/<kind>/domain-pricing/` |
| `customer-care/` | Domain Customer Care (0.2.0), formerly Customer success | `…/<kind>/domain-customer-care/` |
| `sales/assembly/` | Sales assembly 0.4.0 (Service › Process › Process step, with SIPOCM) and Sales value map 0.2.0 | `…/resource/domain-sales/…` |
| `commercial-operations/assembly/` | PEO buyer persona graph 0.2.0 (part of the value map) | `…/resource/commercial-operations/persona-graph/…` |

Changes in 0.4.0 (2026-10-21):
- Legal moved to Business Operations. With it went the client service agreement, commercial agreement and clause, and the contract management steps, agreement terms and statuses that were in Pricing and contracts.
- Partner and channel became an L2 domain of Sales.
- The previous versions are in `../archive/superseded-0.4.0/`.

Some primitives shared well beyond this area, such as benefit, payroll, insurance, workers' compensation and claim, still live in the Commercial Operations vocabulary. Every area may cite them (D27). They will move to the HR Service Operations domain that owns each subject once those domains are built.

The workbook `sales/Sales Services and Processes.xlsx` catalogs the Sales services on the APQC PCF.
