# PEO Outcome Benchmark — KE Workbench ingestion set

Instances for the outcome-driven benchmark: 7 client personas, 26 jobs (22 core functional, 4 consumption chain), 8 job steps and 224 desired outcomes, plus the classes, theme taxonomy and metric vocabulary they reference. Status: **Draft 0.1.0**, pending business and compliance SME review.

## Load order and target named graphs

Load each file into its own named graph (Model Manager → *Target Named Graph URI*, or GraphDB Import → *Named graph*), in this order:

| # | File | Named graph |
|---|------|-------------|
| 1 | `00-jobs-to-be-done-ontology.ttl` | `<https://www.insperity.com/graph/outcome-benchmark/ontology>` |
| 2 | `01-job-steps.ttl` | `<https://www.insperity.com/graph/outcome-benchmark/job-steps>` |
| 3 | `02-client-personas.ttl` | `<https://www.insperity.com/graph/outcome-benchmark/client-personas>` |
| 4 | `03-jobs.ttl` | `<https://www.insperity.com/graph/outcome-benchmark/jobs>` |
| 5 | `04-desired-outcomes.ttl` | `<https://www.insperity.com/graph/outcome-benchmark/desired-outcomes>` |
| 6 | `05-benchmark-theme-taxonomy.ttl` | `<https://www.insperity.com/graph/outcome-benchmark/benchmark-themes>` |
| 7 | `06-outcome-metric-type-vocabulary.ttl` | `<https://www.insperity.com/graph/outcome-benchmark/outcome-metric-types>` |
| 8 | `07-service-traceability.ttl` | `<https://www.insperity.com/graph/outcome-benchmark/service-traceability>` |

Or import `outcome-benchmark-all.trig` once — it carries the same eight graphs.

## Namespaces (Semantic Governance v1.8 §3.2)

| Prefix | IRI | Holds |
|---|---|---|
| `jtbd:` | `https://www.insperity.com/ontology/jobs-to-be-done/` | 7 classes, 24 properties |
| `ob:` | `https://www.insperity.com/resource/outcome-benchmark/` | 265 individuals |
| `theme:` | `https://www.insperity.com/taxonomy/benchmark-theme/` | 11 themes (one scheme) |
| `metric:` | `https://www.insperity.com/vocabulary/outcome-metric-type/` | 5 metric types |
| `hr:` | `http://example.org/hrservices/ddd#` | business-model services and domains (referenced only, in file 07) |

Individual names: `ob:BusinessOwner`, `ob:DefineStep`, `ob:Job-J01`, `ob:Outcome-O001`. The benchmark IDs (P1, J01, O001, DEF) are kept in `jtbd:hasIdentifier`, so survey data keyed on those IDs joins directly.

## Conventions applied

- Preferred labels spell acronyms out (FMLA → Family and Medical Leave Act); the original wording is kept in `skos:altLabel` and, for outcomes, verbatim in `jtbd:hasOutcomeStatement` — that is the survey wording.
- Every outcome carries its importance and satisfaction survey questions.
- Relations are stored in both directions (`hasJobExecutor` / `executesJob`, `hasDesiredOutcome` / `isOutcomeOfJob`) so queries work without OWL inference.
- Every instance has `dcterms:created` and a draft `skos:editorialNote`.

## Validation

Checked with the Workbench's own `ke-turtle.js` parser and the `ke-rules.js` Standards Conformance rules (all 17 rules, 4851 triples): **0 errors, 0 warnings, 0 info findings**. All internal references resolve; the only unresolved Insperity IRI is the ontology's `owl:versionIRI`, which is expected.

## Things to decide

- **Root class.** `jtbd:JobsToBeDoneElement` is a subclass of `prov:Entity` so it has a named parent. Repoint that one triple to your core ontology's root when it exists.
- **Business-model links.** File 07 uses the HR Services & PEO model's current `hr:` IRIs. When that model moves under `https://www.insperity.com/`, regenerate or rewrite file 07 only — nothing else depends on it.

## Example query

```sparql
PREFIX jtbd: <https://www.insperity.com/ontology/jobs-to-be-done/>
PREFIX skos: <http://www.w3.org/2004/02/skos/core#>
SELECT ?persona ?job ?outcome ?statement WHERE {
  ?p a jtbd:ClientPersona ; jtbd:hasIdentifier "P1" ; skos:prefLabel ?persona ; jtbd:executesJob ?j .
  ?j skos:prefLabel ?job ; jtbd:hasDesiredOutcome ?o .
  ?o jtbd:hasIdentifier ?outcome ; jtbd:hasOutcomeStatement ?statement .
} ORDER BY ?outcome
```
