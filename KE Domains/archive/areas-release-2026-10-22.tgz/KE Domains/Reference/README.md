# Reference

`apqc-pcf/`: the APQC Process Classification Framework reference registry, the APQC PCF Taxonomy 0.1.0 at `…/taxonomy/apqc-pcf/` (D25). It is read only, built by `../_build/build_reference.py`.

- **Source.** APQC Cross-Industry PCF 7.2.1, category 3.0 Market and Sell Products and Services (199 elements). The PCF is © APQC and used with attribution. APQC has since released 8.0, so check the numbering against a licensed copy, then add the other categories.
- **What each element records.** An element (`…/apqc-pcf/element-<APQC ID>`) keeps:
  - APQC's name, as published;
  - its hierarchy number (`skos:notation`);
  - its element ID (`dcterms:identifier`);
  - its level (category, process group, process, activity, task);
  - its one owner domain (`skos:related` to the domain concept in the owner's area taxonomy).
- **How domains use it.** Domain taxonomies link their process kinds to it with `skos:exactMatch` or `skos:broadMatch`; no domain re-creates an APQC element. For example, the Sales census collection process broad-matches 3.5.3, and prospecting exact-matches 3.5.1.1.
- **What it doesn't cover.** External services follow the business model, not APQC.
